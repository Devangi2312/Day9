import java.util.Scanner;

public class ReverseString {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the string to revers the words");
        String str=sc.nextLine();
        String[] c=str.split(" ");
        String[] b=new String[c.length];
        int j=c.length-1;

        for(int i=0;i<c.length;i++)
        {
           b[j]=c[i];
           j--;            
        }
        StringBuffer sb=new StringBuffer();
        for(String s:b)
        {
            sb.append(s);
            sb.append(" ");
        }
        String rev=sb.toString();
        System.out.println("Here is the reversed string::"+rev);
   
    }
}
