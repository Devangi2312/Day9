import java.util.Scanner;

public class ArmstrongNumber {
    public static void main(String[] args) {
        System.out.println("Enter a number:");
        Scanner sc=new Scanner(System.in);
        int num=sc.nextInt();
        int temp=num;
        int sum=0,num1,num2;
        while(temp>0)
        {
            num1=temp%10;
            num2=num1;
            for(int i=0;i<2;i++)
            {
                num1*=num2;
            }
            sum+=num1;
            temp/=10;
        }
        if(num==sum)
        {
            System.out.println(num + " is ArmStrong number.");
        }
        else
        {
            System.out.println(num + " is not ArmStrong number.");
        }

    }
}
