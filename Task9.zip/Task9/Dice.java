import java.util.Scanner;
public class Dice {
    public static int countCombinations(int numDice, int targetSum) {
        if (numDice < 1 || numDice > 6 || targetSum < numDice || targetSum > 6 * numDice) {
            return 0;
        }

        int[][] dp = new int[numDice + 1][targetSum + 1];

        
        dp[0][0] = 1;

        for (int i = 1; i <= numDice; i++) {
            for (int j = 1; j <= targetSum; j++) {
                for (int k = 1; k <= 6; k++) {
                    if (j - k >= 0) {
                        dp[i][j] += dp[i - 1][j - k];
                    }
                }
            }
        }

        return dp[numDice][targetSum];
    }

    public static void main(String[] args) {
        System.out.println("Enter a Dice Number:");
        Scanner sc=new Scanner(System.in);
        int num1=sc.nextInt();
        System.out.println("Enter a Target Sum:");
        Scanner scan=new Scanner(System.in);
        int num2=scan.nextInt();
        System.out.println(countCombinations(num1, num2));  
    }
}

