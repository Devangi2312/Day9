import java.io.*;
public class NullPointer {
    public static void main(String[] args) {
        try{
            String s=null;
            if(s.equals("hi")){
            System.out.println(s);}
        }
        catch(NullPointerException e){
            System.out.println(e);
        }
        System.out.println("Program of NullPointer Exception");
    }
}
