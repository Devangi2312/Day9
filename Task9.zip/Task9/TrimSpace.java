/**Write a program to remove whitespaces from a given String. (Without
using any inbuilt functions) String - "WELCOME TO MV CLOUDS" */
import java.util.Scanner;

public class TrimSpace {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the string to trim spaces");
        String str=sc.nextLine();
        char[] c=str.toCharArray();
        char[] b=new char[str.length()];
        int j=0;

        for(int i=0;i<c.length;i++)
        {
            if(c[i]==' ')
            {
              continue;
            }
            else{
                b[j]=c[i];
                j++;
            }
            
        }
        String str1=String.valueOf(b);
        System.out.println("The space removed string:"+str1);
    }
}
